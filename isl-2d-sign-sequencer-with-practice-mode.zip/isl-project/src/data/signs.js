// Pose convention:
//   shoulder: degrees, rotation of the upper arm away from hanging straight down
//             (0 = arm relaxed at side, ~90 = arm horizontal, ~150-170 = arm raised to head)
//   elbow:    degrees, forward bend of the forearm relative to the upper arm
//   hand:     shape variant rendered by <Hand />
//
// These are simplified, stylized poses built for demo/sequencing purposes —
// they are NOT verified linguistic ISL references. Swap in motion-captured or
// verified pose data before this ships beyond a POC.

export const CATEGORIES = [
  {
    id: 'greetings',
    label: 'Greetings',
    accent: '#5EEAD4',
  },
  {
    id: 'family',
    label: 'Family',
    accent: '#F0B429',
  },
  {
    id: 'numbers',
    label: 'Numbers',
    accent: '#9B8CFF',
  },
  {
    id: 'food',
    label: 'Food & Drink',
    accent: '#FF8A65',
  },
  {
    id: 'emotions',
    label: 'Emotions',
    accent: '#F06292',
  },
];

const REST = { shoulder: 6, elbow: 8, hand: 'relaxed' };

export const SIGNS = [
  // Greetings
  {
    id: 'hello',
    label: 'Hello',
    category: 'greetings',
    right: { shoulder: 118, elbow: 105, hand: 'open' },
    left: REST,
  },
  {
    id: 'thank-you',
    label: 'Thank You',
    category: 'greetings',
    right: { shoulder: 132, elbow: 128, hand: 'flat' },
    left: REST,
  },
  {
    id: 'please',
    label: 'Please',
    category: 'greetings',
    right: { shoulder: 82, elbow: 112, hand: 'flat' },
    left: REST,
  },
  {
    id: 'goodbye',
    label: 'Goodbye',
    category: 'greetings',
    right: { shoulder: 58, elbow: 18, hand: 'open' },
    left: REST,
  },

  // Family
  {
    id: 'mother',
    label: 'Mother',
    category: 'family',
    right: { shoulder: 128, elbow: 138, hand: 'thumb' },
    left: REST,
  },
  {
    id: 'father',
    label: 'Father',
    category: 'family',
    right: { shoulder: 150, elbow: 148, hand: 'thumb' },
    left: REST,
  },
  {
    id: 'brother',
    label: 'Brother',
    category: 'family',
    right: { shoulder: 148, elbow: 148, hand: 'point' },
    left: { shoulder: 32, elbow: 58, hand: 'point' },
  },
  {
    id: 'sister',
    label: 'Sister',
    category: 'family',
    right: { shoulder: 128, elbow: 136, hand: 'point' },
    left: { shoulder: 32, elbow: 58, hand: 'point' },
  },

  // Numbers
  {
    id: 'one',
    label: 'One',
    category: 'numbers',
    right: { shoulder: 68, elbow: 88, hand: 'num1' },
    left: REST,
  },
  {
    id: 'two',
    label: 'Two',
    category: 'numbers',
    right: { shoulder: 68, elbow: 88, hand: 'num2' },
    left: REST,
  },
  {
    id: 'three',
    label: 'Three',
    category: 'numbers',
    right: { shoulder: 68, elbow: 88, hand: 'num3' },
    left: REST,
  },
  {
    id: 'four',
    label: 'Four',
    category: 'numbers',
    right: { shoulder: 68, elbow: 88, hand: 'num4' },
    left: REST,
  },
  {
    id: 'five',
    label: 'Five',
    category: 'numbers',
    right: { shoulder: 68, elbow: 88, hand: 'num5' },
    left: REST,
  },

  // Food & Drink
  {
    id: 'eat',
    label: 'Eat',
    category: 'food',
    right: { shoulder: 140, elbow: 150, hand: 'fist' },
    left: REST,
  },
  {
    id: 'water',
    label: 'Water',
    category: 'food',
    right: { shoulder: 130, elbow: 140, hand: 'point' },
    left: REST,
  },
  {
    id: 'drink',
    label: 'Drink',
    category: 'food',
    right: { shoulder: 142, elbow: 152, hand: 'fist' },
    left: REST,
  },
  {
    id: 'hungry',
    label: 'Hungry',
    category: 'food',
    right: { shoulder: 60, elbow: 90, hand: 'flat' },
    left: REST,
  },

  // Emotions
  {
    id: 'happy',
    label: 'Happy',
    category: 'emotions',
    right: { shoulder: 58, elbow: 92, hand: 'flat' },
    left: { shoulder: 58, elbow: 92, hand: 'flat' },
  },
  {
    id: 'sad',
    label: 'Sad',
    category: 'emotions',
    right: { shoulder: 108, elbow: 112, hand: 'flat' },
    left: { shoulder: 108, elbow: 112, hand: 'flat' },
  },
  {
    id: 'love',
    label: 'Love',
    category: 'emotions',
    right: { shoulder: 74, elbow: 100, hand: 'fist' },
    left: { shoulder: 74, elbow: 100, hand: 'fist' },
  },
  {
    id: 'angry',
    label: 'Angry',
    category: 'emotions',
    right: { shoulder: 34, elbow: 92, hand: 'claw' },
    left: REST,
  },
];

export const REST_POSE = { right: REST, left: REST };
