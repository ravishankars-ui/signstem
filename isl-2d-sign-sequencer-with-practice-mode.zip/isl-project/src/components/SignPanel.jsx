import React from 'react';
import { CATEGORIES, SIGNS } from '../data/signs.js';

export default function SignPanel({ activeCategory, onSelectCategory, onAddSign }) {
  const category = CATEGORIES.find((c) => c.id === activeCategory) ?? CATEGORIES[0];
  const signsInCategory = SIGNS.filter((s) => s.category === category.id);

  return (
    <section className="panel" aria-label="Sign subjects">
      <div className="panel-header">
        <h2>Subjects</h2>
        <p>Pick a subject, then tap a sign to add it to the sequence.</p>
      </div>

      <div className="tabs" role="tablist">
        {CATEGORIES.map((c) => (
          <button
            key={c.id}
            role="tab"
            aria-selected={c.id === category.id}
            className={`tab ${c.id === category.id ? 'tab-active' : ''}`}
            style={{ '--tab-accent': c.accent }}
            onClick={() => onSelectCategory(c.id)}
          >
            {c.label}
          </button>
        ))}
      </div>

      <div className="sign-grid">
        {signsInCategory.map((s) => (
          <button
            key={s.id}
            className="sign-chip"
            style={{ '--chip-accent': category.accent }}
            onClick={() => onAddSign(s)}
          >
            {s.label}
          </button>
        ))}
      </div>
    </section>
  );
}
