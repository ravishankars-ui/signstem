import React from 'react';
import Hand from './Hand.jsx';
import { REST_POSE } from '../data/signs.js';

const UPPER_LEN = 60;
const FORE_LEN = 54;

function Arm({ side, pose, accent, isPlaying }) {
  const mirror = side === 'left' ? -1 : 1; // left = viewer's right side
  const shoulderX = 150 + mirror * 46;
  const shoulderY = 156;
  const shoulderRot = mirror * -pose.shoulder;
  const elbowRot = mirror * pose.elbow * 0.6;

  return (
    <g transform={`translate(${shoulderX} ${shoulderY}) rotate(${shoulderRot})`} className="arm-joint">
      {/* upper arm */}
      <rect x={-9} y={0} width={18} height={UPPER_LEN} rx={9} fill="url(#sleeveGrad)" stroke="#1b2030" strokeWidth="1.5" />
      <g transform={`translate(0 ${UPPER_LEN}) rotate(${elbowRot})`} className="arm-joint">
        {/* forearm */}
        <rect x={-8} y={0} width={16} height={FORE_LEN} rx={8} fill="#F0C9A0" stroke="#DDAE7E" strokeWidth="1.5" />
        <g transform={`translate(0 ${FORE_LEN})`} className={isPlaying ? 'hand-signing' : undefined}>
          <Hand variant={pose.hand} accent={accent} />
        </g>
      </g>
    </g>
  );
}

export default function Avatar({ pose = REST_POSE, accent = '#5EEAD4', isPlaying = false }) {
  return (
    <svg viewBox="0 0 300 420" className="avatar-svg" role="img" aria-label="ISL avatar performing a sign">
      <defs>
        <linearGradient id="bodyGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#2A3145" />
          <stop offset="100%" stopColor="#1B2030" />
        </linearGradient>
        <linearGradient id="sleeveGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#33405E" />
          <stop offset="100%" stopColor="#242C40" />
        </linearGradient>
        <radialGradient id="faceGlow" cx="50%" cy="35%" r="65%">
          <stop offset="0%" stopColor="#FBE1BD" />
          <stop offset="100%" stopColor="#F0C9A0" />
        </radialGradient>
      </defs>

      <g className="avatar-idle">
        {/* torso */}
        <path
          d="M 108 150 Q 150 138 192 150 L 202 330 Q 150 344 98 330 Z"
          fill="url(#bodyGrad)"
          stroke="#11141d"
          strokeWidth="2"
        />
        {/* collar accent */}
        <path d="M 130 150 Q 150 164 170 150" stroke={accent} strokeWidth="3" fill="none" strokeLinecap="round" opacity="0.8" />

        {/* left arm (viewer's right) drawn first so right arm overlaps at rest */}
        <Arm side="left" pose={pose.left} accent={accent} isPlaying={isPlaying} />

        {/* neck + head */}
        <rect x="138" y="112" width="24" height="30" rx="8" fill="#EAC191" />
        <circle cx="150" cy="90" r="44" fill="url(#faceGlow)" stroke="#DDAE7E" strokeWidth="1.5" />
        {/* simple face */}
        <circle cx="134" cy="86" r="3.2" fill="#2A2018" />
        <circle cx="166" cy="86" r="3.2" fill="#2A2018" />
        <path d="M 134 106 Q 150 116 166 106" stroke="#8A5A34" strokeWidth="2.4" fill="none" strokeLinecap="round" />
        {/* hair */}
        <path d="M 106 84 Q 108 40 150 40 Q 192 40 194 84 Q 178 58 150 58 Q 122 58 106 84 Z" fill="#2B2320" />

        {/* right arm (viewer's left) drawn last so it reads in front for most signs */}
        <Arm side="right" pose={pose.right} accent={accent} isPlaying={isPlaying} />
      </g>

      {/* base shadow */}
      <ellipse cx="150" cy="404" rx="70" ry="10" fill="#000" opacity="0.25" />
    </svg>
  );
}
