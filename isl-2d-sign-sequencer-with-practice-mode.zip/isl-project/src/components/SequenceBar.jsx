import React from 'react';

export default function SequenceBar({ sequence, currentIndex, isPlaying, onPlay, onStop, onClear, onRemove, playbackSpeed, onPlaybackSpeedChange, loopSequence, onLoopChange }) {
  return (
    <section className="sequence-bar" aria-label="Sign sequence">
      <div className="sequence-controls">
        <button className="btn btn-primary" onClick={onPlay} disabled={sequence.length === 0 || isPlaying}>
          {isPlaying ? 'Playing…' : 'Play sequence'}
        </button>
        <button className="btn" onClick={onStop} disabled={!isPlaying}>Stop</button>
        <button className="btn btn-ghost" onClick={onClear} disabled={sequence.length === 0}>Clear</button>
        <label className="speed-control">
          <span>Speed</span>
          <select value={playbackSpeed} onChange={(e) => onPlaybackSpeedChange(e.target.value)} aria-label="Playback speed">
            <option value="slow">Slow</option>
            <option value="normal">Normal</option>
            <option value="fast">Fast</option>
          </select>
        </label>
        <label className="loop-control">
          <input type="checkbox" checked={loopSequence} onChange={(e) => onLoopChange(e.target.checked)} />
          Loop
        </label>
      </div>

      <div className="sequence-track">
        {sequence.length === 0 && <span className="sequence-empty">No signs queued yet — tap a subject below to start building a sequence.</span>}
        {sequence.map((s, i) => (
          <span
            key={`${s.id}-${i}`}
            className={`sequence-token ${isPlaying && i === currentIndex ? 'sequence-token-active' : ''}`}
          >
            {s.label}
            {!isPlaying && (
              <button aria-label={`Remove ${s.label}`} className="sequence-token-remove" onClick={() => onRemove(i)}>×</button>
            )}
          </span>
        ))}
      </div>
    </section>
  );
}
