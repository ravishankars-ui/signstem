import React from 'react';

// Renders a stylized hand at the local origin, fingers extending in -y.
// `variant` selects the finger configuration for a given sign.
export default function Hand({ variant = 'relaxed', accent = '#5EEAD4' }) {
  const skin = '#F0C9A0';
  const skinShade = '#DDAE7E';

  const finger = (x, len, rot = 0, width = 8) => (
    <rect
      key={`${x}-${len}-${rot}`}
      x={x - width / 2}
      y={-len}
      width={width}
      height={len}
      rx={width / 2}
      fill={skin}
      stroke={skinShade}
      strokeWidth="1.5"
      transform={`rotate(${rot} ${x} 0)`}
    />
  );

  const curledFinger = (x, rot = 0) => (
    <circle key={`c-${x}-${rot}`} cx={x} cy={-6} r={6} fill={skin} stroke={skinShade} strokeWidth="1.5"
      transform={`rotate(${rot} ${x} 0)`} />
  );

  let fingers = null;
  let extraGlow = false;

  switch (variant) {
    case 'open':
      fingers = [-16, -8, 0, 8, 16].map((x, i) => finger(x, i === 0 || i === 4 ? 24 : 30, i === 0 ? -18 : i === 4 ? 18 : 0));
      extraGlow = true;
      break;
    case 'flat':
      fingers = [
        finger(-15, 20, -8),
        ...[-6, 3, 12].map((x) => finger(x, 30)),
        finger(20, 22, 30, 9), // thumb
      ];
      break;
    case 'fist':
      fingers = [-10, -3, 4, 11].map((x) => curledFinger(x));
      break;
    case 'point':
      fingers = [
        finger(-2, 32, 0),
        ...[-10, 6, 13].map((x) => curledFinger(x)),
      ];
      extraGlow = true;
      break;
    case 'thumb':
      fingers = [
        ...[-10, -3, 4, 11].map((x) => curledFinger(x)),
        finger(18, 22, 55, 9),
      ];
      break;
    case 'claw':
      fingers = [-14, -6, 2, 10].map((x) => finger(x, 16, x < 0 ? -20 : 20, 8));
      break;
    case 'num1':
      fingers = [finger(-2, 32, 0)];
      break;
    case 'num2':
      fingers = [finger(-6, 32, -6), finger(4, 32, 6)];
      break;
    case 'num3':
      fingers = [finger(-10, 30, -10), finger(0, 32, 0), finger(10, 30, 10)];
      break;
    case 'num4':
      fingers = [-13, -4.5, 4.5, 13].map((x, i) => finger(x, 30, (i - 1.5) * 6));
      break;
    case 'num5':
      fingers = [-16, -8, 0, 8, 16].map((x, i) => finger(x, i === 0 || i === 4 ? 24 : 30, (i - 2) * 9));
      break;
    default:
      fingers = [-9, -3, 3, 9].map((x) => curledFinger(x, 0));
  }

  return (
    <g className={extraGlow ? 'hand-active' : undefined}>
      {fingers}
      <ellipse cx="0" cy="6" rx="15" ry="17" fill={skin} stroke={skinShade} strokeWidth="1.5" />
      {extraGlow && (
        <circle cx="0" cy="0" r="34" fill="none" stroke={accent} strokeOpacity="0.35" strokeWidth="2" className="hand-ring" />
      )}
    </g>
  );
}
