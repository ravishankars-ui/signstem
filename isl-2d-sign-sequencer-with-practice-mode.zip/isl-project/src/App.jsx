import React, { useEffect, useRef, useState } from 'react';
import Avatar from './components/Avatar.jsx';
import SignPanel from './components/SignPanel.jsx';
import SequenceBar from './components/SequenceBar.jsx';
import { CATEGORIES, REST_POSE } from './data/signs.js';
import './App.css';

const PLAYBACK_SPEEDS = { slow: 1900, normal: 1300, fast: 700 };

export default function App() {
  const [activeCategory, setActiveCategory] = useState(CATEGORIES[0].id);
  const [sequence, setSequence] = useState([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(-1);
  const [playbackSpeed, setPlaybackSpeed] = useState('normal');
  const [loopSequence, setLoopSequence] = useState(false);
  const timerRef = useRef(null);

  const activeAccent = CATEGORIES.find((c) => c.id === activeCategory)?.accent ?? '#5EEAD4';

  const addSign = (sign) => {
    setSequence((prev) => [...prev, sign]);
  };

  const removeSign = (index) => {
    setSequence((prev) => prev.filter((_, i) => i !== index));
  };

  const clearSequence = () => {
    stopPlayback();
    setSequence([]);
  };

  const stopPlayback = () => {
    clearTimeout(timerRef.current);
    setIsPlaying(false);
    setCurrentIndex(-1);
  };

  const playSequence = () => {
    if (sequence.length === 0) return;
    setIsPlaying(true);
    setCurrentIndex(0);
  };

  useEffect(() => {
    if (!isPlaying) return undefined;
    if (currentIndex >= sequence.length) {
      if (loopSequence && sequence.length > 0) {
        setCurrentIndex(0);
        return undefined;
      }
      stopPlayback();
      return undefined;
    }
    timerRef.current = setTimeout(() => {
      setCurrentIndex((i) => i + 1);
    }, PLAYBACK_SPEEDS[playbackSpeed]);
    return () => clearTimeout(timerRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isPlaying, currentIndex, sequence.length, playbackSpeed, loopSequence]);

  const currentSign = isPlaying && currentIndex >= 0 && currentIndex < sequence.length
    ? sequence[currentIndex]
    : null;

  const pose = currentSign
    ? { right: currentSign.right, left: currentSign.left }
    : REST_POSE;

  const subtitle = currentSign ? currentSign.label : (sequence.length ? 'Ready to play' : 'Waiting for signs…');

  return (
    <div className="app">
      <header className="app-header">
        <div className="brand">
          <span className="brand-mark" aria-hidden="true" />
          <div>
            <h1>ISL Sign Sequencer</h1>
            <p>2D avatar · general-subject sign library</p>
          </div>
        </div>
      </header>

      <main className="app-main">
        <section className="stage">
          <div className="stage-frame" style={{ '--accent': currentSign ? activeAccent : '#5EEAD4' }}>
            <Avatar pose={pose} accent={activeAccent} isPlaying={Boolean(currentSign)} />
          </div>
          <div className="subtitle" aria-live="polite">{subtitle}</div>
          <SequenceBar
            sequence={sequence}
            currentIndex={currentIndex}
            isPlaying={isPlaying}
            onPlay={playSequence}
            onStop={stopPlayback}
            onClear={clearSequence}
            onRemove={removeSign}
            playbackSpeed={playbackSpeed}
            onPlaybackSpeedChange={setPlaybackSpeed}
            loopSequence={loopSequence}
            onLoopChange={setLoopSequence}
          />
        </section>

        <SignPanel
          activeCategory={activeCategory}
          onSelectCategory={setActiveCategory}
          onAddSign={addSign}
        />
      </main>
    </div>
  );
}
